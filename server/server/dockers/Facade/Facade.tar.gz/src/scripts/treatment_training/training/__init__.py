from src.scripts.treatment_training.training.training import Training
