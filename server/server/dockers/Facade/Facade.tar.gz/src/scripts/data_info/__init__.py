from src.scripts.data_info.read_data import DataInfo
