from src.scripts.treatment.TreatData import TreatData
