from src.scripts.predict.predict import Prediction
