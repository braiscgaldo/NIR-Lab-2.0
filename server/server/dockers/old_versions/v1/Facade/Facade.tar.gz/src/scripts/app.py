import sys

sys.path.append('../../')
from src.scripts.data_info.read_data import DataInfo
from src.scripts.treatment_training.data_treatment.data_treatment import DataTreatment
from src.scripts.treatment_training.training.training import Training
from src.scripts.treatment_training.docker_interface import DockerInterface
from src.scripts.authentication.auth import Auth

import threading
from flask import Flask, jsonify, request
import requests

app = Flask(__name__)
app.config['FLASK_ENV'] = 'development'
app.config['HOST'] = '0.0.0.0'
app.config['BUNDLE_ERRORS'] = True


# Parse petition
def parse_request():
    return request.get_json(force=True)


# Creates a session
@app.route('login', methods=['POST'])
def login():
    pass


# Delete a session
@app.route('sign_out', methods=['DELETE'])
def sign_out():
    pass


@app.route('create_user', methods=['POST'])
def create_user(**kwargs):
    if Auth.create_user(username=kwargs['username_auth'], password=kwargs['password_auth'], name=kwargs['name_auth'],
                     surname=kwargs['surname_auth'], email=kwargs['email_auth']):
        return {'message': 'User created'}, 200

    return {'message': 'Internal server error'}, 500


@app.route('edit_user', methods=['POST'])
def edit_user(**kwargs):
    if Auth.edit_user(username=kwargs['username_auth'], password=kwargs['password_auth'], name=kwargs['name_auth'],
                   surname=kwargs['surname_auth'], email=kwargs['email_auth'], new_password=kwargs['new_password_auth']):
        return {'message': 'User created'}, 200

    return {'message': 'Internal server error'}, 500


@app.route('edit_user', methods=['DELETE'])
def drop_user(**kwargs):
    if Auth.drop_user(username=kwargs['username_auth'], password=kwargs['password_auth']):
        return {'message': 'User created'}, 200

    return {'message': 'Internal server error'}, 500


@app.route('edit_user', methods=['GET'])
def info_user(**kwargs):
    info = Auth.info_user(username=kwargs['username_auth'], password=kwargs['password_auth'])
    if info:
        return info, 200

    return {'message': 'Internal server error'}, 500


@app.route('create_user', methods=['GET'])
def list_users(**kwargs):
    users = Auth.list_users()
    if users:
        return users, 200
    return {'message': 'Internal server error'}, 500


@app.route('data_treatment', methods=['GET'])
def list_files(**kwargs):
    files = DataInfo(kwargs['username']).list_files()
    if files:
        return files, 200

    return {'message': 'Internal server error'}, 500


@app.route('data_treatment', methods=['PUT'])
def add_file(**kwargs):
    if DataInfo(kwargs['username']).add_file(kwargs['filename'], kwargs['directory']):
        return {'message': 'Added file'}, 200

    return {'message', 'Internal server error'}, 500


@app.route('data_treatment', methods=['DELETE'])
def delete_file(**kwargs):
    if DataInfo(kwargs['username']).delete_file(kwargs['filename'], kwargs['directory']):
        return {'message': 'File deleted successfully'}, 200

    return {'message': 'Internal server error'}, 500


@app.route('data_treatment', methods=['GET'])
def list_characteristics(**kwargs):
    chars = DataInfo(kwargs['username']).list_characteristics(kwargs['filename'])
    if chars:
        return chars, 200

    return {'message': 'Internal server error'}, 500


@app.route('/training', methods=['POST'])
def training(**kwargs):

    def train_back(**kwargs):
        requests.post('dockers_training_1/training:5050', data=kwargs)

    thread = threading.Thread(target=train_back, kwargs=kwargs)
    thread.start()

    return {"message": "Executing background task..."}, 202


@app.route('/data_treatment', methods=['POST'])
def treat_data(**kwargs):

    def treat_data_back(**kwargs):
        requests.post('dockers_data_treatment_1/data_treatment:5000', data=kwargs)

    thread = threading.Thread(target=treat_data_back(), kwargs=kwargs)
    thread.start()

    return {"message": "Executing background task..."}, 202


operations = {
    'DataTreatment': treat_data,
    'Training': training,
    'ListFiles': list_files,
    'AddFile': add_file,
    'DeleteFile': delete_file,
    'ListCharacteristics': list_characteristics,
    'Login': login,
    'CreateUser': create_user,
    'EditUser': edit_user,
    'DropUser': drop_user,
    'InfoUser': info_user,
    'ListUsers': list_users
}


@app.route('*/', methods=['GET', 'PUT', 'DELETE', 'POST'])
def facade_operation():
    kwargs = parse_request()
    operations[kwargs['type']](kwargs)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=443)
