// variables.js
export const colorForeground = '#EE3744'
export const colorBackground = '#DEEAEE'
export const colorAccent1 = '#EE3744'
export const colorAccent2 = '#5C5E76'
export const colorAccent3 = '#33262D'
